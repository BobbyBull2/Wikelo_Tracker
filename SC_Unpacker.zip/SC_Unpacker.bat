@echo off
setlocal enabledelayedexpansion

:: Default paths (Star Citizen LIVE folder)
set SC_DIR=C:\Program Files\Roberts Space Industries\StarCitizen\LIVE
set P4K_FILE=%SC_DIR%\data.p4k
set OUTPUT_DIR=%SC_DIR%\data

:: What to extract (only localization for overrides; change to * for everything)
set EXTRACT_FILTER=Data/Localization/english/*

:: Temp folder for downloads
set TEMP_DIR=%TEMP%\SC_Unpacker
mkdir "%TEMP_DIR%" 2>nul

:: unp4k download URL (latest from GitHub; update if needed)
set UNP4K_URL=https://github.com/dolkensp/unp4k/releases/download/v3.3.1/unp4k-suite-v3.3.1.zip
set UNP4K_ZIP=%TEMP_DIR%\unp4k.zip
set UNP4K_EXE=%TEMP_DIR%\unp4k.exe

:: Check if data.p4k exists
if not exist "%P4K_FILE%" (
    echo Error: data.p4k not found at %P4K_FILE%. Check your Star Citizen install.
    pause
    exit /b 1
)

:: Download unp4k if not present
if not exist "%UNP4K_EXE%" (
    echo Downloading unp4k from GitHub...
    powershell -Command "Invoke-WebRequest -Uri '%UNP4K_URL%' -OutFile '%UNP4K_ZIP%'"
    if not exist "%UNP4K_ZIP%" (
        echo Failed to download unp4k. Check your internet or try manually from https://github.com/dolkensp/unp4k/releases
        pause
        exit /b 1
    )
    echo Extracting unp4k.exe...
    powershell -Command "Expand-Archive -Path '%UNP4K_ZIP%' -DestinationPath '%TEMP_DIR%' -Force"
    if not exist "%UNP4K_EXE%" (
        echo Failed to extract unp4k.exe. Try manually.
        pause
        exit /b 1
    )
)

:: Create output dir
mkdir "%OUTPUT_DIR%" 2>nul

:: Run unpack (change to OUTPUT_DIR, extract, then back)
pushd "%OUTPUT_DIR%"
echo Extracting with filter: %EXTRACT_FILTER%
"%UNP4K_EXE%" "%P4K_FILE%" %EXTRACT_FILTER%
popd

:: Cleanup temp (optional; comment out if you want to keep)
rd /s /q "%TEMP_DIR%" 2>nul

echo Done! Files extracted to %OUTPUT_DIR%.
echo Now launch Star Citizen to use the localized overrides.
pause